/**
 *
 * 私有方法  通过 var VA 变量实例
 *
 * 静态方法  通过 let V 实例
 *
 * 属性方法后期需要整合
 *
 * Class方法实例直接通过 constructor
 *
 * 代码中静态方法暂时只有 hideAnimation
 *
 * */

/**
 * VirusAnimation front-end frame
 *
 * Created by duanyc
 *
 */

/**
 * VirusAnimation文件夹内文件名字与位置不能改变
 * */

console.time(`VirusAnimationJS RunTimer`);
(function (window) {

    let {location, VAjsUrl, core_selector, dom_root_, mode, root_, $this, connectTag, loadingAnimationTimeout, versions} = {

        location: window.location,

        VAjsUrl: document.currentScript.src,

        core_selector: ``,

        dom_root_: document.documentElement,

        mode: [`development`, `production`],

        root_: ``,

        $this: ``,

        connectTag: ``,

        loadingAnimationTimeout: ``,

        versions: Object.freeze({
            versions: 0.51,
            author: 'duanyc',
            update: '2017/10/10',
            ECMAScript: 6
        }),

    };

    class VirusAnimation {

        constructor(selector) {
            if (Object.is(selector, undefined)) selector = `body`;
            core_selector = selector;
            root_ = $('body');
            // 写入原型
            this.mode = mode[0];
            this.origin = location.origin;
            this.selector = core_selector;
            this.callback = null;
            this.versions = versions;

            // 修改指向
            this.loadingAnimation.bind(this);
            this.prompt.bind(this);
            this.alertModal.bind(this);
            this.dropdown.bind(this);
            this.search.bind(this);

            // prototype
            Object.assign(this.__proto__,
                {
                    checkFont() {
                        const font = 'font-awesome';
                        let [ele, haveLink] = [$('link'), false];
                        ele.each((i, e) => {
                            if ($(e).prop('href').indexOf(font) !== -1) haveLink = true;
                        });
                        if (!haveLink) this.error('请引入font-awesome.min.css');
                    },

                    checkElement(selector) {
                        if (Object.is(typeof selector[0], 'string')) {
                            if (Object.is(typeof selector, 'string')) {
                                if ($(selector).length > 0) {
                                    $(selector).remove();
                                }
                            } else if (Object.is(typeof selector, 'object')) {
                                $.each(selector, function (i, e) {
                                    if ($(e).length > 0) {
                                        $(e).remove();
                                    }
                                })
                            }
                        } else {
                            return false;
                        }
                    },

                    error(msg) {
                        throw new Error(msg);
                    },

                    buildConnect(connectType, animationFileName) {
                        let lock_ = false;
                        const
                            [arr = VAjsUrl.split('/'), path = arr.slice(0, arr.length - 2)] = [];

                        if (Object.is(connectType, 'link')) {
                            $.each($(`[V-connect-link="${animationFileName}"]`),
                                (i, e) => {
                                    if (Object.is($(e).attr(`v-connect-link`), animationFileName)) lock_ = true;
                                });

                            if (lock_) {
                                return;
                            } else {
                                connectTag =
                                    `<link rel="stylesheet" V-connect-link="${animationFileName}" href="${path.join('/')}/css/${animationFileName}.css">`;
                            }

                        } else {
                            $.each($(`[V-connect-script="${animationFileName}"]`),
                                (i, e) => {
                                    if (Object.is($(e).attr(`V-connect-script`), animationFileName)) lock_ = true;
                                });

                            if (lock_) {
                                return;
                            } else {
                                connectTag =
                                    `<script V-connect-script="${animationFileName}" src="${path.join('/')}/dependent/${connectType}/${animationFileName}.js">`;

                            }
                        }

                        $(`head`).append(connectTag);
                    },

                    randomId() {
                        return `${Math.floor(Math.random() * Date.now()).toString(36)}` +
                            `${(Date.now() * parseInt(Math.random() * 100)).toString(36)}`;
                    },

                    elementRegister(e, fn) {
                        if ($(e).length > 0) {
                            fn();
                        } else {
                            return this;
                        }
                    },

                    fullScroll(t, s) {
                        let n = $(`body`);
                        if (Object.is(t, 'hide')) {
                            n.bind('mousewheel', () => false).css('overflowY', 'hidden');
                        } else if (Object.is(t, 'show')) {
                            n.unbind('mousewheel').css('overflowY', s);
                        }
                    }
                }
            );
            if (Object.is(typeof selector, 'string') || !selector || Object.is(typeof selector, 'object')) {
                return this;
            } else {
                throw new Error(`请按照正确格式传值`);
            }
        }

        // return this.prototype;
        _proto() {
            return this.__proto__;
        }

        static versions() {
            return versions;
        }

        /**
         * @method: VA(parentElement).loadingAnimation()
         * */
        loadingAnimation(animationType, text = ``) {

            let {
                body: $body,
                NULL: virusAnimationBox,
                NULL: boxCenter,
                NULL: boxLod,
                NULL: loadingText,
                NULL: RotateTransform,
                NULL: ScaleTransformCircle,
                NULL: CircleScaleLoadingCircle,
                _this: _this
            } = {
                body: $('body'),
                NULL: '',
                _this: this
            };
            const typeCheck = [
                'rotate',
                'scale',
                'circleScale',
                'canvasLoading',
                'bgInit'
            ];

            _this.checkElement("div[VA-initBox='loading']");

            $(window).keypress((event) => {
                if (Object.is(event.which, 88) && event.shiftKey) VA().hideAnimation();
            });

            // if (Object.is(text, '') || Object.is(text, undefined)) text = '';

            if (text.length > 12) text = text.substr(0, 11) + ' ...';

            $body.attr('VA-scrollType', $body.css('overflowY'));
            _this.fullScroll('hide');

            loadingAnimationTimeout = setTimeout(() => {
                if ($('div[VA_initBox="loading"]').is(':hidden')) {
                    VA().hideAnimation();
                    VA().prompt('请求服务器长时间无反应，或超时');
                    clearTimeout(loadingAnimationTimeout);
                }
            }, 60000);

            if (Object.is(typeCheck.indexOf(animationType), -1)) return _this.error('Check your animationType');

            if (Object.is(animationType, 'rotate')) {

                let template = () => {
                    let array = [];
                    for (let i = 0; i < 3; i++) {
                        array.push($('<div></div>'));
                    }
                    array.push($('<span></span>'));
                    array.push($('<i></i>'));
                    return array;
                };

                [virusAnimationBox, boxCenter, boxLod, loadingText, RotateTransform] = template();

                $(virusAnimationBox).addClass('loading_initBox').attr('VA-initBox', 'loading').css({
                    'top': '0',
                    'left': '0'
                });
                $(virusAnimationBox).append(
                    $(boxCenter).addClass('loading_content').append($(boxLod).addClass('loading_initBox_lod'))
                );

                $(boxLod).append($(RotateTransform).addClass('fa fa-spinner'), $(loadingText).html(text));

                $(this.selector).append(virusAnimationBox);

            }

            else if (Object.is(animationType, 'scale')) {

                let template = () => {
                    let array = [];
                    for (let i = 0; i < 4; i++) {
                        array.push($('<div></div>'));
                    }
                    array.push($('<span></span>'));
                    return array;
                };

                [virusAnimationBox, boxCenter, boxLod, ScaleTransformCircle, loadingText] = template();

                $(virusAnimationBox).addClass('loading_initBox').attr('VA-initBox', 'loading').css({
                    'top': '0',
                    'left': '0'
                });
                $(virusAnimationBox).append(
                    $(boxCenter).addClass('loading_content').append($(boxLod).addClass('loading_initBox_lod'))
                );

                $(boxLod).append(
                    $(ScaleTransformCircle).clone().addClass('loading_initBox_circle circle_1'),
                    $(ScaleTransformCircle).clone().addClass('loading_initBox_circle circle_2'),
                    $(ScaleTransformCircle).clone().addClass('loading_initBox_circle circle_1'),
                    $(loadingText).html(text)
                );

                $(this.selector).append(virusAnimationBox);

            }

            else if (Object.is(animationType, 'circleScale')) {

                let template = () => {
                    let array = [];
                    for (let i = 0; i < 4; i++) {
                        array.push($('<div></div>'));
                    }
                    array.push($('<span></span>'));
                    return array;
                };

                [virusAnimationBox, boxCenter, boxLod, CircleScaleLoadingCircle, loadingText] = template();

                $(virusAnimationBox).addClass('loading_initBox').attr('VA-initBox', 'loading').css({
                    'top': '0',
                    'left': '0'
                });
                $(virusAnimationBox).append(
                    $(boxCenter).addClass('loading_content').append($(boxLod).addClass('loading_initBox_lod'))
                );

                $(boxLod).append(
                    $('<div class="loading_position"></div>').append($(CircleScaleLoadingCircle).clone().addClass('loading_circle'))
                );

                $(boxLod).children().append($(CircleScaleLoadingCircle).clone().addClass('loading_circle'), $(loadingText));
                //暂时不考虑这个动画加入文字
                // $(boxLod).children().append($(loadingText).html(text));

                $(this.selector).append(virusAnimationBox);

            }

            else if (Object.is(animationType, 'canvasLoading')) {

                let [
                    M = Math,
                    PI = M.PI,
                    TWOPI = PI * 2,
                    HALFPI = PI / 2,
                    canvas = document.createElement('canvas'),
                    ctx = canvas.getContext('2d'),
                    width = canvas.width = 350,
                    height = canvas.height = 350,
                    cx = width / 2,
                    cy = height / 2,
                    count = 40,
                    sizeBase = 0.1,
                    sizeDiv = 5,
                    tick = 0
                ] = [];
                ctx.translate(cx, cy);

                (function loop() {
                    requestAnimationFrame(loop);
                    ctx.clearRect(-width / 2, -height / 2, width, height);
                    ctx.fillStyle = '#fff';
                    let [
                        angle = tick / 8,
                        radius = -50 + M.sin(tick / 15) * 100,
                        size
                    ] = [];

                    for (let i = 0; i < count; i++) {
                        angle += PI / 64;
                        radius += i / 30;
                        size = sizeBase + i / sizeDiv;

                        ctx.beginPath();
                        ctx.arc(M.cos(angle) * radius, M.sin(angle) * radius, size, 0, TWOPI, false);
                        ctx.fillStyle = 'rgba(248, 97, 72, 0.8)';
                        ctx.fill();

                        ctx.beginPath();
                        ctx.arc(M.cos(angle) * -radius, M.sin(angle) * -radius, size, 0, TWOPI, false);
                        ctx.fillStyle = 'rgba(38, 189, 209, 0.8)';
                        ctx.fill();

                        ctx.beginPath();
                        ctx.arc(M.cos(angle + HALFPI) * radius, M.sin(angle + HALFPI) * radius, size, 0, TWOPI, false);
                        ctx.fillStyle = 'rgba(89, 109, 192, 0.8)';
                        ctx.fill();

                        ctx.beginPath();
                        ctx.arc(M.cos(angle + HALFPI) * -radius, M.sin(angle + HALFPI) * -radius, size, 0, TWOPI);
                        ctx.fillStyle = 'rgba(101, 55, 129, 0.8)';
                        ctx.fill();
                    }
                    tick++;
                })();

                if (Object.is(text, '') || Object.is(text, undefined)) text = null;

                let template = () => {
                    let array = [];
                    for (let i = 0; i < 3; i++) {
                        array.push($('<div></div>'));
                    }
                    return array;
                };

                [virusAnimationBox, boxCenter, boxLod] = template();

                $(virusAnimationBox).addClass('loading_initBox').attr('VA-initBox', 'loading').css({
                    'top': '0',
                    'left': '0'
                });
                $(virusAnimationBox).append(
                    $(boxCenter).addClass('loading_content').append($(boxLod).addClass('loading_initBox_lod')));

                $(boxLod).append($(canvas));

                $(this.selector).append(virusAnimationBox);

                $('.loading_initBox_lod').addClass('clearfix').css({
                    'width': 350,
                    'height': 350,
                    'marginLeft': -175,
                    'marginTop': -175
                });

            }

            else if (Object.is(animationType, 'bgInit')) {

                const [bodyWidth, bodyHeight] = [root_.outerWidth(), root_.outerHeight()];

                let loaders;

                let template = () => {
                    let array = [];
                    for (let i = 0; i < 2; i++) {
                        array.push($('<div></div>'));
                    }
                    array.push($('<main></main>'));
                    return array;
                };

                [loaders, boxLod, virusAnimationBox] = template();

                $(this.selector).append($('<background></background>'));

                $(virusAnimationBox).append(loaders);
                $(loaders).addClass('loaders').append($(boxLod).addClass('loader'));

                $(boxLod)
                    .append('<div class="loader-inner ball-clip-rotate-multiple"></div>')
                    .find('div').html('应用初始化中 .');

                $(this.selector).append(virusAnimationBox);

                setInterval(() => {
                    let ldt = $(boxLod).find('div').html();
                    if (ldt.split('.').length < 5) {
                        $(boxLod).find('div').html(ldt + '.');
                    }
                    if (Object.is(ldt.split('.').length, 5)) {
                        $(boxLod).find('div').html('应用初始化中 ');
                    }

                }, 745);

                setTimeout(() => {
                    $('.loader').css({
                        marginLeft: '-' + $(boxLod).width() / 2 + 'px',
                        marginTop: '-' + $(boxLod).height() / 2 + 'px'
                    })
                }, 1)
            }
        }

        /**
         * @method: VA().hideLoadingBox
         * */
        static hideAnimation() {
            const [loadingBox, main, _this] = [$(`div[VA-initBox="loading"]`), $('main'), new this];

            if (main.length > 0) {
                main.remove();
                $('background').remove();
                return false;
            }

            if (loadingBox.length === 0) return _this._proto().error(`请先加载动画再清除动画`);

            clearTimeout(loadingAnimationTimeout);

            loadingBox.fadeOut('slow');

            _this._proto().fullScroll('show', $('body').attr('VA-scrollType'));

            $(`.loading_initBox_lod`).remove();
        }

        /**
         * @method: VA().prompt
         * */
        prompt(text = `没有输入提示文字`) {
            const [
                allPrompt = $(`div[VA-initBox=prompt]`),
                promptBox = document.createElement('div'),
                promptTitle = document.createElement('span'),
                promptContent = document.createElement('p')
            ] = [];

            $(promptBox)
                .attr('VA-initBox', 'prompt').addClass('VA_prompting_box')
                .append(
                    $(promptTitle).addClass('VA_prompting_title'),
                    $(promptContent).addClass('VA_prompting_content')
                );

            $(promptTitle).html('提示');
            $(promptContent).html(text);

            if (this.selector === '' || this.selector === undefined) this.selector = 'body';

            $(this.selector).append($(promptBox));
            $(promptBox).fadeIn('slow').css('top', '15px');

            let promptHideAnimation = ele => {
                const currentNode = $(ele);
                setTimeout(() => {
                    currentNode.animate({
                        // top: '800px'
                        // transform:'translateY(800px)'
                    }, 1234, () => {
                        currentNode.css('transform', 'scale(0.1) translateX(1200px)');
                        currentNode.fadeOut('slow');
                        setTimeout(() => {
                            currentNode.remove();
                        }, 700);
                    });

                }, 3000)

            };

            if (allPrompt.length === 0) {
                $(promptBox).animate({
                    top: '15px',
                    right: 0
                }, 'fast', function () {
                    promptHideAnimation(this);
                });
            } else {
                let [gatherTopNum, gatherRightNum] = [15, 0];

                allPrompt.each((i, e) => {

                    gatherTopNum += $(e)[0].offsetHeight + 15;

                    // 浮动排版 没写完..
                    // if (gatherTopNum > window.screen.availHeight - $(promptBox).height()){
                    //     // console.log($(promptBox));
                    //     gatherTopNum = 15;
                    //     gatherRightNum = $(promptBox).offset().left - $(promptBox).width() - 60;
                    // }else{
                    //     gatherTopNum += $(e)[0].offsetHeight + 15;
                    // }

                    // console.warn(`=======================================`);
                    // console.log(`current top ${gatherTopNum}`);
                    // console.log(`current right ${window.screen.availHeight}`);
                    // console.warn(`=======================================`);
                });

                $(promptBox).animate({
                    top: `${gatherTopNum}px`,
                    right: `${gatherRightNum}px`
                }, 'fast', function () {
                    promptHideAnimation(this);
                });
            }
        }

        /**
         * @method: VA().alertModal()
         * */
        alertModal(selector, successCallback, errorCallback) {
            let [
                txt = selector,
                backdrop = $('<div class="alertModal_backdrop"></div>'),
                modal = $('<div class="VA_modal" V-modal="temporary"></div>'),
                dialog = $('<div class="VA_dialog" VA-modal-id="V_temporary"></div>'),
                title = $('<div class="VA_modal_title"></div>'),
                content = $('<div class="VA_modal_content"></div>'),
                footer = $('<div class="VA_modal_footer"></div>'),
                btn = $('<button class="VA_btn"></button>'),
                $body = $('body'),
                s = $body.css('overflowY'),
                _this = this
            ] = [];

            _this._proto().checkElement(['[V-modal="temporary"]', '.alertModal_backdrop']);
            _this._proto().fullScroll('hide');

            let VA_modal_hide = type => {
                if (Object.is(type, 'V_temporary')) {
                    backdrop.fadeOut().css('opacity', 0);

                    $(`div[V-modal="temporary"]`).css('transform', 'translateY(-1000px)');

                    const alertModalTimeout = setInterval(() => {
                        _this._proto().checkElement(['[V-modal="temporary"]', '.alertModal_backdrop']);
                        clearInterval(alertModalTimeout);
                    }, 770);

                } else {
                    backdrop.fadeOut().css('opacity', 0);
                    $(type).css('transform', 'translateY(-1000px)');
                    const backdropInterval = setInterval(() => {
                        if (backdrop.is(':hidden')) {
                            backdrop.remove();
                            $(type).parent().hide();
                            clearInterval(backdropInterval);
                        }
                    }, 100);
                    backdrop.remove();
                }
                _this._proto().fullScroll('show', s);
            };

            let VA_modal_clickRegister = type => {
                const [
                    cancel = $(`[VA-modal-btn="cancel"]`),
                    confirm = $(`[ VA-modal-btn="confirm"]`),
                    modal = $(`div[V-modal="temporary"]`)
                ] = [];
                cancel.unbind();
                confirm.unbind();
                modal.unbind();
                $(type).unbind();

                cancel.click(() => {
                    VA_modal_hide(type);
                    errorCallback.apply($this);
                });

                confirm.click(() => {
                    VA_modal_hide(type);
                    successCallback.apply($this);
                });

                if (Object.is(type, 'V_temporary')) {
                    modal.click(eve => {
                        if (eve.target === this) VA_modal_hide(type);
                    })
                } else {
                    $(`.VA_modal`).click(eve => {
                        if (eve.target === this) VA_modal_hide(type);
                    })
                }

            };

            if (Object.is(typeof selector, 'string')) {
                if (selector.charAt(0) === '#') {

                    selector = `div[VA-modal-id="${selector.substring(1, selector.length)}"]`;

                    if ($(selector).length === 0) _this._proto().error('未获取到当前元素ID，请重新输入');

                    $(selector).parent().show();
                    $(selector).parent().after(backdrop);
                    $(selector).fadeIn().css('transform', 'translateY(0px)');
                    $(selector).show().css('opacity', 1);

                    const alertModalTimeout = setInterval(() => {
                        const temporary = $(selector);
                        let [
                            style = temporary.css('transform'),
                            matrix = style.split(',')
                        ] = [];

                        if (matrix[matrix.length - 1].split(')')[0] * 1 === 0) {
                            VA_modal_clickRegister(selector);
                            clearInterval(alertModalTimeout);
                        }
                    }, 770);

                } else {
                    let [
                        successBtn = btn.clone().attr('VA-modal-btn', 'confirm').html('确认'),
                        cancelBtn = btn.clone().attr('VA-modal-btn', 'cancel').html('取消')
                    ] = [];

                    title.append($('<div><i class="fa fa-exclamation"></i><span>提示</span></div>'))
                        .append($('<i class="fa fa-times" VA-modal-btn="cancel"></i>'));
                    content.append($('<span class="VA_modal_content_placeholder">' + txt + '</span>'));
                    footer.append($('<div class="VA_modal_btnGroups"></div>').append(cancelBtn).append(successBtn));

                    modal.append(dialog.append(title).append(content).append(footer));

                    $body.append(backdrop);
                    backdrop.before(modal);

                    //fadein
                    setTimeout(() => {
                        modal.show();
                        dialog.fadeIn();
                        backdrop.fadeIn();
                        dialog.css('transform', 'translateY(0)');
                    }, 10);

                    VA_modal_clickRegister('V_temporary');
                }
            } else {
                _this._proto().error('方法参数错误，输入ID或者需要创建模态框内的文字');
            }
        }

        /**
         * @method： VA().loadingTable
         * @use： 加载表格 不考虑
         * */
        loadingTable(config, request) {
            let table, th, tr, td;
            table = document.createElement('table');
            th = document.createElement('thead');
            tr = document.createElement('tr');
            td = document.createElement('td');
            let thr = document.createElement('tr');


            // tbody tr
            for (let i = 0, l = 3; i < l; i++) {
                $(tr).append($(td).clone(true).html(1231233));
            }

            //thead tr
            for (let j = 0, k = 6; j < k; j++) {
                $(thr).append($(td).clone(true).html('这是表头'));
            }
            $(th).append($(thr));
            $(table).prepend($(th));
            $(table).append($(tr));

            root_.append($(table).prop('class', 'table table-hover table-bordered'));


            console.log(table);
            console.log('userConfig -> ', config.id);
            //request('你好');
        }

        /**
         * @method: VA().dropdown()
         * */
        dropdown(direction = 'down', callback) {
            let [
                dropMenu = $(`[V-labelledby="${this.selector}"]`),
                $_this = $(this.selector),
                alertTimeOut,
                $_temporary,
                _this = this
            ] = [];

            if (this.selector === undefined || this.selector.charAt(0) !== '#')
                return _this._proto().error('请获取元素id后，再执行下拉框操作');

            if (typeof direction !== 'string') return _this._proto().error('请输入正确参数');

            let dropDownHide = () => {
                dropMenu.children('li:nth-child(odd)').css('transform', 'translateX(200px)');
                dropMenu.children('li:nth-child(even)').css('transform', 'translateX(-200px)');

                let hideTimeout = setTimeout(() => {
                    $_this.parent().removeClass('open');
                    dropMenu.hide();
                    $_this.find('span').css('transform', 'rotateX(180deg)');

                    clearTimeout(hideTimeout);
                }, 285);
            };

            if (dropMenu.is(':hidden')) {

                $(this.selector).parent().addClass('open');
                dropMenu.prop('style', '');
                if (direction === 'down') {
                    dropMenu.css({
                        left: 0,
                        top: `100%`
                    })
                } else if (direction === 'up') {
                    dropMenu.css({
                        left: 0,
                        bottom: `100%`
                    });
                } else {
                    _this._proto().error('请输入正确参数');
                }

                dropMenu.show();
                $_this.find('span').css('transform', 'rotateX(360deg)');

                alertTimeOut = setTimeout(() => {
                    dropMenu.find('li').each((i, e) => {
                        $(e).css('transform', 'translateX(0)');
                    });
                    root_.click((eve) => {

                        dropDownHide();

                        $.each(dropMenu.find('li').children(), (i, e) => {
                            if (eve.target === e) {
                                $_this.html($(eve.target).html());
                                $_this.append($('<span class="caret"></span>'));

                                if ($(eve.target).data('jsonData') === undefined) {
                                    $_temporary = eve.target.innerText;
                                } else {
                                    $_temporary = $(eve.target).data('jsonData');
                                }
                                if (typeof callback === 'function') callback.apply($this, [$_temporary]);
                            }
                        });

                        root_.unbind();

                    });
                    clearTimeout(alertTimeOut);
                }, 1);

            } else if (dropMenu.is(':hidden')) {
                dropDownHide();
            }
            return $this;
        }

        /**
         * @method: VA().search()
         * */
        search(data, callback) {
            let [
                $this = $('input[V-searchInput=' + this.selector + ']'),
                width = $this.outerWidth(),
                method = $this.attr('V-searchInput-method'),
                listDirection = $this.attr('V-searchInput-listDirection'),
                maxHeight = $this.attr('V-searchInput-maxHeight'),
                _this = this,
            ] = [];

            _this._proto().buildConnect('autocomplete', 'jquery.autocomplete');

            const divResize = setInterval(() => {
                if ($this.length > 0) {
                    clearInterval(divResize);
                    $this.css({
                        'max-height': maxHeight + 'px',
                        overflowY: 'auto'
                    });
                }
            }, 100);

            $this.AutoComplete({
                data: data,
                width: width,
                emphasis: true,                       // true  false
                async: true,                         // true  false
                ajaxDataType: 'json',               // xml  json
                listDirection: listDirection,      // up  down
                ajaxType: method,                 // GET  POST
                afterSelectedHandler(data) {
                    if (Object.is(typeof callback, `function`)) {
                        _this.callback = data.value;
                        callback.apply(_this, [data.value, data]);
                    }
                },
                emphasisHandler(keyword, data) {
                    const regex = new RegExp("(" + keyword.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1") + ")", 'ig');
                    data.label = data.label.replace(regex, "<span class='V_searchInput_emphasis'>$1</span>");
                },
                onerror(msg) {
                    console.error(msg);
                }
            });

        }

        /**
         * @method:
         * */
        then() {
            debugger;
        }

        /**
         * @method: console
         * */
        alertConsole() {
            let [con, alert] =
                [
                    console,
                    [`%cYou are running VirusAnimation in development mode`,
                        `%cYou are running VirusAnimation in production mode`]
                ];

            Object.is(this.mode, `development`) ? alert = alert[0] : alert = alert[1];

            con.log(alert, `font-size:1.2rem;background-image: linear-gradient(to right, #2792ff 2%, #4458a1 2%, #7146e5 1%, #ab06e5 5%, #e5496b 40%,#E5BF3A 100%);color:transparent;-webkit-background-clip:text;`);
        }

    }

    // 私有方法
    window.VA = selector => new VirusAnimation(selector);
    // 静态方法
    window.V = VirusAnimation;

    $(function () {

        /**
         * @method: class .VA_fullScreen
         * @use: fullScreen init
         * */
        VA()._proto().elementRegister('.VA_fullScreen', () => {
            $('.VA_fullScreen').each((i, e) => {
                $(e).click(() => {
                    if (root_.attr('VA_fullScreen') === undefined || root_.attr('VA_fullScreen') === 'false') {

                        root_.attr('VA_fullScreen', true);
                        if (dom_root_.requestFullscreen) {
                            dom_root_.requestFullscreen();
                        } else if (dom_root_.mozRequestFullScreen) {
                            dom_root_.mozRequestFullScreen();
                        } else if (dom_root_.webkitRequestFullscreen) {
                            dom_root_.webkitRequestFullscreen();
                        } else if (dom_root_.msRequestFullscreen) {
                            dom_root_.msRequestFullscreen();
                        }

                    } else {
                        root_.attr('VA_fullScreen', false);
                        if (document.exitFullscreen) {
                            document.exitFullscreen();
                        } else if (document.mozCancelFullScreen) {
                            document.mozCancelFullScreen();
                        } else if (document.webkitExitFullscreen) {
                            document.webkitExitFullscreen();
                        }
                    }
                })
            });
        });

        /**
         * @method: fileInputRegister
         * */
        VA()._proto().elementRegister('[V-fileInput="#image"]', () => {

            $('[V-fileInput="#image"]').each((i, e) => {

                $(e).click(() => {
                    let [id = $(e).attr('V-fileInput'), file, reader] = [];

                    $(this).change(eve => {

                        [file, reader] = [eve.target.files[0], new FileReader()];

                        reader.onload = e => $(id).prop('src', e.target.result);

                        reader.readAsDataURL(file);
                    })

                });
            });
        });

        /**
         * @method: deleteInputRegister
         * */
        VA()._proto().elementRegister('[V-deleteInput]', () => {
            $('[V-deleteInput]').keyup(function () {
                const [
                    i = $(`<i class="fa fa-times-circle-o V_delete_input"></i>`),
                    parent = $(this).parent(),
                    $i = parent.find('i'),
                    mathCount = parseInt($(this).outerHeight() / 3) * 2
                ] = [];

                parent.css('position', 'relative');

                i.css({
                    width: mathCount,
                    height: mathCount,
                    fontSize: mathCount
                });

                i.click(eve => {
                    i.prev().val('');
                    $(eve.currentTarget).hide();
                });

                if ($i.length > 0) {
                    if ($(this).val().length > 0) {
                        $i.show();
                    } else {
                        $i.hide();
                    }
                } else if ($i.length === 0) {
                    parent.append(i);
                    i.css({
                        top: `50%`,
                        right: `.5%`,
                        marginTop: `-${mathCount / 2}px`
                    });

                    $(this).css('paddingRight', i.outerHeight() + 13);
                }

            });
        });

        //style Init
        let styleInit = `
        .V_dropdown-menu{display:none;color:red}
        `;
        $(document).find('head').prepend(`<style type="text/css">${styleInit}</style>`);

    });

    // log
    VA().alertConsole();
    // font
    VA()._proto().checkFont();
    // module
    VA()._proto().buildConnect('link', 'va_animation_module_style');
    // animation
    VA()._proto().buildConnect('link', 'va_animation_rotate_style');
    VA()._proto().buildConnect('link', 'va_animation_scale_style');
    VA()._proto().buildConnect('link', 'va_animation_circleScale_style');
    //other
    VA()._proto().buildConnect('link', 'otherAnimation/loaders');
    VA()._proto().buildConnect('link', 'otherAnimation/loaderInit');


})(window);
console.timeEnd(`VirusAnimationJS RunTimer`);
